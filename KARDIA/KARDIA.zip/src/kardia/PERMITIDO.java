/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kardia;

/**
 *
 * @author ADRIAN COSTA
 */
public class PERMITIDO {
    static public boolean                                   AlwaysOnTop = false;
    static public int                                       WWW = 0;
    static public int                                       HHH = 0;
    static public int                                       SEPARA0 = 20;
    static public double                                    VOLTS = 2.5;
    static public double                                    Fs = 1500;
    ///
    ///
    /// 
    static public int                                       TYPE_Plot = 1;
    
    ///
    ///
    /// RGB GRILLA
    static public int                                       R_G = 210;
    static public int                                       G_G = 210;
    static public int                                       B_G = 210;
    ///
    ///
    /// RGB LINEA
    static public int                                       R_L = 0;
    static public int                                       G_L = 0;
    static public int                                       B_L = 200;
    ///
    ///
    ///
    ///
    ///
    ///
    static public  boolean                                  BARLOW = false;
    static public  boolean                                  PassByPass = false;
    static public  boolean                                  Visible_Signal = true;
    ///
    ///
    ///
}
