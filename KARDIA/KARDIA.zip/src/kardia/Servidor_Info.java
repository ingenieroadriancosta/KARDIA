package kardia;
public class Servidor_Info{
    ///
    ///
    static public String                        Kardia_URL      = "http://www.kardiaupc1.gq/";
    static public String                        Servidor        = "mysql5012.site4now.net";
    static public String                        Usuario         = "a625c3_kardia";
    static public String                        PassWord        = "kardia2020";
    static public String                        DataBase        = "db_" + Usuario;
    ///
    static public String                        Servidor_File   = Kardia_URL;
    static public String                        Usuario_File    = "kardiaUPC1";
    static public String                        PassWord_File   = "kardia2020";
    static public String                        FTP_PATH        = "kardia";
    ///
    ///
    ///
    ///
    static public boolean                       BTopmost = false;
    ///
    ///
    ///
    ///
    ///
}
